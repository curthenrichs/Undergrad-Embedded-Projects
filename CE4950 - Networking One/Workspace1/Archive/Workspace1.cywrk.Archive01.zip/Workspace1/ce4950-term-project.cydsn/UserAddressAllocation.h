
#ifndef USERADDRESSALLOCATION_H
#define USERADDRESSALLOCATION_H
    
#include <stdint.h>
    
typedef enum UserAddressLevel {
    USER_ADDRESS_LVL_1,
    USER_ADDRESS_LVL_2,
    USER_ADDRESS_LVL_3
} UserAddressLevel_e;

typedef enum UserName {
    NETWORK_BROADCAST,
    PAMELA_ANTAR,
    SAMUEL_CONROY,
    SAMUEL_HALLERMAN,
    CURT_HENRICHS,
    JOSEPHINE_LOCURTO,
    ANTHONY_MARLOWE,
    MUNAZZA_NAEEM,
    MATHEW_PIKE,
    SHAHRUKE_QURESHI,
    DIVIN_RAMACHANDRAN,
    ALEXANDER_ROBERTS,
    REID_RUMACK,
    JOHN_SELFORS,
    ZACHARY_STANKE,
    ANDREW_STOEHR,
    TYLER_WELLS,
    JOHNATHON_WENZEL,
    JOSHUA_WIDDER,
    ANDREW_WINSTON,
    XU_ZHANG,
    ALWIN_ABRAHAM,
    NATHEER_ALKHUNAIZY,
    CALEB_BAHR,
    PALLAV_BANIK,
    ZACHARY_BARTMER,
    NICHOLAS_BOUSKA,
    RILEY_BRUCE,
    GERALD_GEHRKE,
    BENTON_GEIMER,
    ADAM_HAY,
    QUIHAO_JIN,
    SETH_LIABRAATEN,
    MAURIZIO_PADILLA,
    HUNTER_PARKS,
    NIRVAN_POONACHA_THEETHIRA,
    JOHN_SCHLEDERER,
    JAMES_SHIPP,
    LAWRENCE_SKUSE,
    WOODROW_WALKER,
    DMITRI_WATERS,
    JAMES_WINDORJJ,
    KAMITH_MIRISSAGE,
    
    //Used for table allocation
    _USER_TABLE_SIZE
} UserName_e;
    

void user_init(void);

uint8_t user_id_to_address(UserName_e name, UserAddressLevel_e lvl);

UserName_e user_address_to_id(uint8_t addr);

UserName_e user_string_to_id(const char* str);

const char* user_id_to_string(UserName_e name);

uint8_t user_string_to_address(const char* str, UserAddressLevel_e lvl);

const char* user_address_to_string(uint8_t addr);
    
    
#endif
    