
#include "UserAddressAllocation.h"

typedef struct User_Info {
    UserName_e name;
    const char* str;
    uint8_t lvl_1_addr;
    uint8_t lvl_2_addr;
    uint8_t lvl_3_addr;
} User_Info_t;


static User_Info_t _userTable[_USER_TABLE_SIZE];


void user_init(void){
    _userTable[NETWORK_BROADCAST].name = NETWORK_BROADCAST;
    _userTable[NETWORK_BROADCAST].str = "broadcast";
    _userTable[NETWORK_BROADCAST].lvl_1_addr = 0x00;
    _userTable[NETWORK_BROADCAST].lvl_2_addr = 0x00;
    _userTable[NETWORK_BROADCAST].lvl_3_addr = 0x00;
    
    _userTable[PAMELA_ANTAR].name = PAMELA_ANTAR;
    _userTable[PAMELA_ANTAR].str = "pamela antar";
    _userTable[PAMELA_ANTAR].lvl_1_addr = 0x01;
    _userTable[PAMELA_ANTAR].lvl_2_addr = 0x02;
    _userTable[PAMELA_ANTAR].lvl_3_addr = 0x03;
    
    _userTable[SAMUEL_CONROY].name = SAMUEL_CONROY;
    _userTable[SAMUEL_CONROY].str = "samuel conroy";
    _userTable[SAMUEL_CONROY].lvl_1_addr = 0x04;
    _userTable[SAMUEL_CONROY].lvl_2_addr = 0x05;
    _userTable[SAMUEL_CONROY].lvl_3_addr = 0x06;
    
    _userTable[SAMUEL_HALLERMAN].name = SAMUEL_HALLERMAN;
    _userTable[SAMUEL_HALLERMAN].str = "samuel hallerman";
    _userTable[SAMUEL_HALLERMAN].lvl_1_addr = 0x07;
    _userTable[SAMUEL_HALLERMAN].lvl_2_addr = 0x08;
    _userTable[SAMUEL_HALLERMAN].lvl_3_addr = 0x09;
    
    _userTable[CURT_HENRICHS].name = CURT_HENRICHS;
    _userTable[CURT_HENRICHS].str = "curt henrichs";
    _userTable[CURT_HENRICHS].lvl_1_addr = 0x0A;
    _userTable[CURT_HENRICHS].lvl_2_addr = 0x0B;
    _userTable[CURT_HENRICHS].lvl_3_addr = 0x0C;
    
    _userTable[JOSEPHINE_LOCURTO].name = JOSEPHINE_LOCURTO;
    _userTable[JOSEPHINE_LOCURTO].str = "josephine locurto";
    _userTable[JOSEPHINE_LOCURTO].lvl_1_addr = 0x0D;
    _userTable[JOSEPHINE_LOCURTO].lvl_2_addr = 0x0E;
    _userTable[JOSEPHINE_LOCURTO].lvl_3_addr = 0x0F;
    
    _userTable[ANTHONY_MARLOWE].name = ANTHONY_MARLOWE;
    _userTable[ANTHONY_MARLOWE].str = "anthony marlowe";
    _userTable[ANTHONY_MARLOWE].lvl_1_addr = 0x10;
    _userTable[ANTHONY_MARLOWE].lvl_2_addr = 0x11;
    _userTable[ANTHONY_MARLOWE].lvl_3_addr = 0x12;
    
    _userTable[MUNAZZA_NAEEM].name = MUNAZZA_NAEEM;
    _userTable[MUNAZZA_NAEEM].str = "munazza naeem";
    _userTable[MUNAZZA_NAEEM].lvl_1_addr = 0x13;
    _userTable[MUNAZZA_NAEEM].lvl_2_addr = 0x14;
    _userTable[MUNAZZA_NAEEM].lvl_3_addr = 0x15;
    
    _userTable[MATHEW_PIKE].name = MATHEW_PIKE;
    _userTable[MATHEW_PIKE].str = "mathew pike";
    _userTable[MATHEW_PIKE].lvl_1_addr = 0x16;
    _userTable[MATHEW_PIKE].lvl_2_addr = 0x17;
    _userTable[MATHEW_PIKE].lvl_3_addr = 0x18;
    
    _userTable[SHAHRUKE_QURESHI].name = SHAHRUKE_QURESHI;
    _userTable[SHAHRUKE_QURESHI].str = "shahruke qureshi";
    _userTable[SHAHRUKE_QURESHI].lvl_1_addr = 0x19;
    _userTable[SHAHRUKE_QURESHI].lvl_2_addr = 0x1A;
    _userTable[SHAHRUKE_QURESHI].lvl_3_addr = 0x1B;
    
    _userTable[DIVIN_RAMACHANDRAN].name = DIVIN_RAMACHANDRAN;
    _userTable[DIVIN_RAMACHANDRAN].str = "divin ramachandran";
    _userTable[DIVIN_RAMACHANDRAN].lvl_1_addr = 0x1C;
    _userTable[DIVIN_RAMACHANDRAN].lvl_2_addr = 0x1D;
    _userTable[DIVIN_RAMACHANDRAN].lvl_3_addr = 0x1E;
    
    _userTable[ALEXANDER_ROBERTS].name = ALEXANDER_ROBERTS;
    _userTable[ALEXANDER_ROBERTS].str = "alexander roberts";
    _userTable[ALEXANDER_ROBERTS].lvl_1_addr = 0x1F;
    _userTable[ALEXANDER_ROBERTS].lvl_2_addr = 0x20;
    _userTable[ALEXANDER_ROBERTS].lvl_3_addr = 0x21;
    
    _userTable[REID_RUMACK].name = REID_RUMACK;
    _userTable[REID_RUMACK].str = "reid rumack";
    _userTable[REID_RUMACK].lvl_1_addr = 0x22;
    _userTable[REID_RUMACK].lvl_2_addr = 0x23;
    _userTable[REID_RUMACK].lvl_3_addr = 0x24;
    
    _userTable[JOHN_SELFORS].name = JOHN_SELFORS;
    _userTable[JOHN_SELFORS].str = "john selfors";
    _userTable[JOHN_SELFORS].lvl_1_addr = 0x25;
    _userTable[JOHN_SELFORS].lvl_2_addr = 0x26;
    _userTable[JOHN_SELFORS].lvl_3_addr = 0x27;
    
    _userTable[ZACHARY_STANKE].name = ZACHARY_STANKE;
    _userTable[ZACHARY_STANKE].str = "zachary stanke";
    _userTable[ZACHARY_STANKE].lvl_1_addr = 0x28;
    _userTable[ZACHARY_STANKE].lvl_2_addr = 0x29;
    _userTable[ZACHARY_STANKE].lvl_3_addr = 0x2A;
    
    
}

uint8_t user_id_to_address(UserName_e name, UserAddressLevel_e lvl){
    
}

UserName_e user_address_to_id(uint8_t addr){
    
}

UserName_e user_string_to_id(const char* str){
    
}

const char* user_id_to_string(UserName_e name){
    
}

uint8_t user_string_to_address(const char* str, UserAddressLevel_e lvl){
    
}

const char* user_address_to_string(uint8_t addr){
    
}