/**
 * DataLinkLayer
 * @author Curt Henrichs
 * @date 1-26-18
 *
 * Aggregates all of the low level driver components into a cohesive interface 
 * for higher level application services. Additionally, wraps low-level bus
 * read/write into a data frame containing header and routing information.
 *
 * Low-Level drivers include
 *  - CSMA_CD_Bus
 *  - ChannelMonitor
 *  - Transmitter
 *  - Receiver
 */

//=============================================================================
//                                 Libraries
//=============================================================================
    
#include "DataLinkLayer.h"

//=============================================================================
//                            Data Structure Declaration
//=============================================================================
    
typedef struct DLL_Header {
    uint8_t start;
    uint8_t version;
    uint8_t src;
    uint8_t dst;
    uint8_t msg_len;
    uint8_t crc_usage;
    uint8_t crc;
} DLL_Header_t;

//=============================================================================
//                         Public Function Implementation
//=============================================================================
    
void dll_init(void){
        
}

void dll_set_user(UserName_e user){
    
}

UserName_e dll_get_user(void){
    
}

bool dll_update(void){
    
}

bool dll_write(DLL_Message_t* message){
    
}

bool dll_has_data(void){
    
}

uint8_t dll_read(DLL_Message_t* message){
   
}