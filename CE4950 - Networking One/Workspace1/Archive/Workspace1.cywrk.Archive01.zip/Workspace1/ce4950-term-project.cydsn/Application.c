/**
 * Application
 * @author Curt Henrichs
 * @date 1-11-18
 *
 * Application layer demo program for term project.
 * TODO: Stubbed module for future
 */

//=============================================================================
//                                 Libraries
//=============================================================================

#include "Application.h"

//=============================================================================
//                         Public Function Implementation
//=============================================================================

/**
 * Application main function will run demo program for term project
 * @return --ignore
 */
int app_main(void){
 
    //TODO implement this
    
    while(1){/* flow capture loop */}
    
    return 0; /* ignore */
}