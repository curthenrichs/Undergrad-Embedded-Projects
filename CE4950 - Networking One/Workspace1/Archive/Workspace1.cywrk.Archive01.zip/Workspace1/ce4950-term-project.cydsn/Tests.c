/**
 * Tests
 * @author Curt Henrichs
 * @date 1-11-18
 *
 * Tests module encapsulates the test cases applied to the term project. 
 * Each test case is build with reference to a written test plan corresponding
 * to the enumerated week.
 *
 * Before building the application one should verify the TEST_CASE 
 * configuration parameter is valid. Additionally, ensure all necessary 
 * hardware and system drivers are initialized outside of this module.
 */

//=============================================================================
//                                 Libraries
//=============================================================================

#include "Tests.h"

#include "project.h"
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

#include "DataLinkLayer.h"

#include "CSMA_CD_Bus.h"
#include "ChannelMonitor.h"
#include "Transmitter.h"
#include "Receiver.h"
#include "Uart.h"

//=============================================================================
//                       Constant and Macro Definitions : Week 5
//=============================================================================

/** 
 * States for test menu application state-machine.
 */
typedef enum Menu_States {
    MENU_START,     //! Initalization state for state machine
    MENU_DISPLAY,   //! User driven menu
    MENU_UART,      //! Transmit characters from UART
    MENU_NUL,       //! Transmit 0x00
    MENU_REPEAT_1,  //! Transmit 0xAA
    MENU_REPEAT_2,  //! Transmit 0x55
    MENU_ONES       //! Transmit 0xFF
} Menu_States_e;

#define NUM_SELECTABLE_OPTIONS (5) //! Menu selectable states

#define CAPSENSE_SETTLE_TIME  100 //! Time to delay during initialization (ms)

//=============================================================================
//                        Private Function Prototypes : Week 5
//=============================================================================

/** 
 * Display test case menu
 * @param on_enter first entry of state-machine for one-time logic
 * @return next state as selected by user else this state if no selection
 */
static Menu_States_e display(bool on_enter);
/** 
 * UART test case - transmit buffered message from USBUART.
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e uart_mode(bool on_enter);
/** 
 * 0x00 test case - transmit string of 0x00 characters
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e nul_string_mode(bool on_enter);
/** 
 * 0xAA test case - transmit string of 0xAA characters
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e repeat_string_1_mode(bool on_enter);
/** 
 * 0x55 test case - transmit string of 0x55 characters
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e repeat_string_2_mode(bool on_enter);
/** 
 * 0xFF test case - transmit string of 0xFF characters
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e ones_mode(bool on_enter);

//=============================================================================
//                          Private Attribute : Week 5
//=============================================================================

/** 
 * Menu states selected
 */
static Menu_States_e MENU_OPTIONS_LIST[NUM_SELECTABLE_OPTIONS];
/** 
 * Menu string naming the options
 */
static const char* MENU_OPTIONS_TAGS[NUM_SELECTABLE_OPTIONS];

//=============================================================================
//                         Public Function Implementation
//=============================================================================

/**
 * Testing module main function will run selected test week
 * @return --ignore
 */
int tests_main(void){
    
    //initialization routine
    CyGlobalIntEnable; 
    
    csma_bus_init();
    cm_init();
    tx_init();
    uart_init();
    rx_init();
    
    LCD_Start();
    LCD_ClearDisplay();
    CapSense_Start();
    CyDelay(CAPSENSE_SETTLE_TIME);
    CapSense_InitializeAllBaselines();
    
    switch(CURRENT_TEST){
        case TEST_CASE_WEEK_3:
            tests_week3();
            break;
        case TEST_CASE_WEEK_5:
            tests_week5();
            break;
        case TEST_CASE_WEEK_6:
            tests_week6();
            break;
        case TEST_CASE_WEEK_8:
            tests_week8();
            break;
    }
    
    while(1){/* flow capture loop */}
    
    return 0; /* ignore */
}

/** 
 * Test for week 3 is to determine functionality of the channel monitor
 */
void tests_week3(void){
    CM_State_e ch_state = cm_get_bus_state();
    const char* str = NULL;
    uint8_t state_trig = 0;
    
    while(true){
        
        ch_state = cm_get_bus_state();
        switch(ch_state){
            case CM_STATE_INIT:
                str = "INIT";
                break;
            case CM_STATE_IDLE:
                str = "IDLE";
                break;
            case CM_STATE_BUSY:
                str = "BUSY";
                break;
            case CM_STATE_COLLISION:
                str = "COLLISION";
                break;
            default:
                str = "";
                break;
        }
        
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString(str);
        LCD_Position(1,0);
        LCD_PrintHexUint8(state_trig);
        state_trig |= CM_Test_State_Reg_Read();
        CyDelay(10);
    }
}

/**
 * Test for week 5 is a state-machine with user driven menu to select between
 * several test cases for transmitter functionality tests.
 */
void tests_week5(void){
    MENU_OPTIONS_LIST[0] = MENU_UART;
    MENU_OPTIONS_LIST[1] = MENU_NUL;
    MENU_OPTIONS_LIST[2] = MENU_REPEAT_1;
    MENU_OPTIONS_LIST[3] = MENU_REPEAT_2;
    MENU_OPTIONS_LIST[4] = MENU_ONES;
    
    MENU_OPTIONS_TAGS[0] = "UART";
    MENU_OPTIONS_TAGS[1] = "REPEAT 0x00";
    MENU_OPTIONS_TAGS[2] = "REPEAT 0xAA";
    MENU_OPTIONS_TAGS[3] = "REPEAT 0x55";
    MENU_OPTIONS_TAGS[4] = "REPEAT 0xFF";
    
    // Test State-Machine for menu driven control
    Menu_States_e curr_state = MENU_DISPLAY;
    Menu_States_e next_state = MENU_START;
    bool on_enter = true;
    while(true){
        
        //update capacitive touch user input
        if(!CapSense_IsBusy()){
            CapSense_UpdateEnabledBaselines();
            CapSense_ScanEnabledWidgets();
        }
        
        switch(curr_state){
            case MENU_DISPLAY:
                next_state = display(on_enter);
                break;
            case MENU_UART:
                next_state = uart_mode(on_enter);
                break;
            case MENU_NUL:
                next_state = nul_string_mode(on_enter);
                break;
            case MENU_REPEAT_1:
                next_state = repeat_string_1_mode(on_enter);
                break;
            case MENU_REPEAT_2:
                next_state = repeat_string_2_mode(on_enter);
                break;
            case MENU_ONES:
                next_state = ones_mode(on_enter);
                break;
            default:
                next_state = MENU_DISPLAY;
                break;
        }
        
        on_enter = (next_state != curr_state);
        curr_state = next_state;
    }
}

/** 
 * Test week 6 will verify correct behavior for interaction between channel
 * monitor and transmission module.
 */
void tests_week6(void){
    static char buffer[USBUART_BUFFER_SIZE];
    static char disp[16];
    static char txStr[33];
    static uint8_t txStr_index;
    
    memset(txStr,0,sizeof(txStr));
    txStr_index = 0;
    
    LCD_ClearDisplay();
    LCD_Position(0,0);
    LCD_PrintString("UART:");

    while(true){
        uart_update();
        
        if(uart_has_data()){
            memset(buffer,'\0',sizeof(buffer));
            uint16_t numChar = uart_read(buffer,sizeof(buffer));
            uart_write(buffer,strlen(buffer));
            
            LCD_ClearDisplay();
            LCD_Position(0,0);
            LCD_PrintString("UART:");
            LCD_Position(1,0);
            memcpy(disp,buffer,15);
            disp[15] = 0;
            LCD_PrintString(disp);
            
            bool nl_found = false;
            uint8_t index = 0;
            char c;
            while(!nl_found && txStr_index < (sizeof(txStr)-1) && index < numChar){
                c = buffer[index];
                index++;
                if(c == '\n' || c == '\r'){
                    txStr[txStr_index] = '\0';
                    nl_found = true;
                }else{
                    txStr[txStr_index] = c;
                }
                txStr_index++;
            }
            
            //buffer full, last character is nul
            if(txStr_index >= (sizeof(txStr)-1)){
                txStr[32] = '\0';
                nl_found = true;
            }
            
            //transmit if newline or full
            if(nl_found){
                txStr_index = 0;
                LCD_Position(1,0);
                LCD_PrintString("Transmitting");
                tx_sf_buffer(txStr,strlen(txStr),0);
                CyDelay(100);
                LCD_Position(1,0);
                LCD_PrintString("            ");
            }
        }
    }
}

/**
 * Test week 8 will test the developed receiver module for valid interpretation
 * of characters. Note that header information is not handled.
 */
void tests_week8(void){
    
    static char txStr[33];
    static uint8_t txStr_index;
    memset(txStr,0,sizeof(txStr));
    txStr_index = 0;
    
    char buffer[USBUART_BUFFER_SIZE];
    char str[17];
    
    LCD_ClearDisplay();
   
    while(1){
        uart_update();
        
        if(uart_has_data()){
            memset(buffer,'\0',sizeof(buffer));
            uint16_t numChar = uart_read(buffer,sizeof(buffer));
            uart_write(buffer,strlen(buffer));
            
            bool nl_found = false;
            uint8_t index = 0;
            char c;
            while(!nl_found && txStr_index < (sizeof(txStr)-1) && index < numChar){
                c = buffer[index];
                index++;
                if(c == '\n' || c == '\r'){
                    txStr[txStr_index] = '\0';
                    nl_found = true;
                }else{
                    txStr[txStr_index] = c;
                }
                txStr_index++;
            }
            
            //buffer full, last character is nul
            if(txStr_index >= (sizeof(txStr)-1)){
                txStr[32] = '\0';
                nl_found = true;
            }
            
            //transmit if newline or full
            if(nl_found){
                txStr_index = 0;
                tx_sf_buffer(txStr,strlen(txStr),0);
            }
        }
        
        if(rx_has_data()){
            uint8_t count = rx_buffer(buffer,sizeof(buffer));
            LCD_ClearDisplay();
            LCD_Position(0,0);
            sprintf(str,"Size: %d",count);
            LCD_PrintString(str);
            LCD_Position(1,0);
            uint8_t cpy = (count < 16) ? count : 16;
            memcpy(str,buffer,cpy);
            str[cpy] = 0;
            //sprintf(str,"ASCII: %d",(uint8_t)(buffer[0]));
            LCD_PrintString(str);
            uart_write(buffer,count);
        }
        
        if(!CapSense_IsBusy()){
            CapSense_UpdateEnabledBaselines();
            CapSense_ScanEnabledWidgets();
        }
        
        if(CapSense_CheckIsWidgetActive(CapSense_LEFT__BTN)){
            LCD_ClearDisplay();   
        }
    }
}

//=============================================================================
//                   Private Function Implementation : Week 5
//=============================================================================

/** 
 * Display test case menu
 * @param on_enter first entry of state-machine for one-time logic
 * @return next state as selected by user else this state if no selection
 */
static Menu_States_e display(bool on_enter){
    static uint8_t index;
    static bool hold;
    
    if(on_enter){
        index = 0;
        hold = true;
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("MENU:");
        LCD_Position(1,0);
        LCD_PrintString(MENU_OPTIONS_TAGS[index]);
    }
    
    bool iterate = CapSense_CheckIsWidgetActive(CapSense_LEFT__BTN);
    if(iterate && !hold){
        index = (index + 1) % NUM_SELECTABLE_OPTIONS;
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("MENU:");
        LCD_Position(1,0);
        LCD_PrintString(MENU_OPTIONS_TAGS[index]);
    }
    hold = iterate;
    
    bool nextState = CapSense_CheckIsWidgetActive(CapSense_RIGHT__BTN);
    Menu_States_e retval = (nextState) ? MENU_OPTIONS_LIST[index] : MENU_DISPLAY;
    return retval;
}

/** 
 * UART test case - transmit buffered message from USBUART.
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e uart_mode(bool on_enter){
    static char buffer[USBUART_BUFFER_SIZE];
    static char disp[16];
    static char txStr[33];
    static uint8_t txStr_index;
    
    if(on_enter){
        memset(txStr,0,sizeof(txStr));
        txStr_index = 0;
        
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("UART:");
    }
    
    uart_update();
        
    if(uart_has_data()){
        memset(buffer,'\0',sizeof(buffer));
        uint16_t numChar = uart_read(buffer,sizeof(buffer));
        uart_write(buffer,strlen(buffer));
        
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("UART:");
        LCD_Position(1,0);
        memcpy(disp,buffer,15);
        disp[15] = 0;
        LCD_PrintString(disp);
        
        bool nl_found = false;
        uint8_t index = 0;
        char c;
        while(!nl_found && txStr_index < (sizeof(txStr)-1) && index < numChar){
            c = buffer[index];
            index++;
            if(c == '\n' || c == '\r'){
                txStr[txStr_index] = '\0';
                nl_found = true;
            }else{
                txStr[txStr_index] = c;
            }
            txStr_index++;
        }
        
        //buffer full, last character is nul
        if(txStr_index >= (sizeof(txStr)-1)){
            txStr[32] = '\0';
            nl_found = true;
        }
        
        //transmit if newline or full
        if(nl_found){
            txStr_index = 0;
            LCD_Position(1,0);
            LCD_PrintString("Transmitting");
            tx_buffer(txStr,strlen(txStr));
            CyDelay(100);
            LCD_Position(1,0);
            LCD_PrintString("            ");
        }
    }
    
    bool returnMenu = CapSense_CheckIsWidgetActive(CapSense_LEFT__BTN);
    Menu_States_e retval = (returnMenu) ? MENU_DISPLAY : MENU_UART;
    return retval;
}

/** 
 * 0x00 test case - transmit string of 0x00 characters
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e nul_string_mode(bool on_enter){
    static bool hold;
    bool active = CapSense_CheckIsWidgetActive(CapSense_RIGHT__BTN);
    
    if(on_enter){
        hold = true;
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("REPEAT 0x00:");
    }
    
    if(active && !hold){
        LCD_Position(1,0);
        LCD_PrintString("Transmitting");
        char buffer[] = { 0x00, 0x00, 0x00, 0x00 };
        tx_buffer(buffer, sizeof(buffer)); 
        CyDelay(100);
        LCD_Position(1,0);
        LCD_PrintString("            ");
    }
    hold = active;
    
    bool returnMenu = CapSense_CheckIsWidgetActive(CapSense_LEFT__BTN);
    Menu_States_e retval = (returnMenu) ? MENU_DISPLAY : MENU_NUL;
    return retval;
}

/** 
 * 0xAA test case - transmit string of 0xAA characters
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e repeat_string_1_mode(bool on_enter){
    static bool hold;
    bool active = CapSense_CheckIsWidgetActive(CapSense_RIGHT__BTN);
    
    if(on_enter){
        hold = true;
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("REPEAT 0xAA:");
    }
    
    if(active && !hold){
        LCD_Position(1,0);
        LCD_PrintString("Transmitting");
        char buffer[] = { 0xAA, 0xAA, 0xAA, 0xAA };
        tx_buffer(buffer, sizeof(buffer)); 
        CyDelay(100);
        LCD_Position(1,0);
        LCD_PrintString("            ");
    }
    hold = active;
    
    bool returnMenu = CapSense_CheckIsWidgetActive(CapSense_LEFT__BTN);
    Menu_States_e retval = (returnMenu) ? MENU_DISPLAY : MENU_REPEAT_1;
    return retval;
}

/** 
 * 0x55 test case - transmit string of 0x55 characters
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e repeat_string_2_mode(bool on_enter){
    static bool hold;
    bool active = CapSense_CheckIsWidgetActive(CapSense_RIGHT__BTN);
    
    if(on_enter){
        hold = true;
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("REPEAT 0x55:");
    }
    
    if(active && !hold){
        LCD_Position(1,0);
        LCD_PrintString("Transmitting");
        char buffer[] = { 0x55, 0x55, 0x55, 0x55 };
        tx_buffer(buffer, sizeof(buffer)); 
        CyDelay(100);
        LCD_Position(1,0);
        LCD_PrintString("            ");
    }
    hold = active;
    
    bool returnMenu = CapSense_CheckIsWidgetActive(CapSense_LEFT__BTN);
    Menu_States_e retval = (returnMenu) ? MENU_DISPLAY : MENU_REPEAT_2;
    return retval;
}

/** 
 * 0xFF test case - transmit string of 0xFF characters
 * @param on_enter first entry of state-machine for one-time logic
 * @return this state until user presses return button
 */
static Menu_States_e ones_mode(bool on_enter){
    static bool hold;
    bool active = CapSense_CheckIsWidgetActive(CapSense_RIGHT__BTN);
    
    if(on_enter){
        hold = true;
        LCD_ClearDisplay();
        LCD_Position(0,0);
        LCD_PrintString("REPEAT 0xFF:");
    }
    
    if(active && !hold){
        LCD_Position(1,0);
        LCD_PrintString("Transmitting");
        char buffer[] = { 0xFF, 0xFF, 0xFF, 0xFF };
        tx_buffer(buffer, sizeof(buffer)); 
        CyDelay(100);
        LCD_Position(1,0);
        LCD_PrintString("            ");
    }
    hold = active;
    
    bool returnMenu = CapSense_CheckIsWidgetActive(CapSense_LEFT__BTN);
    Menu_States_e retval = (returnMenu) ? MENU_DISPLAY : MENU_ONES;
    return retval;
}
