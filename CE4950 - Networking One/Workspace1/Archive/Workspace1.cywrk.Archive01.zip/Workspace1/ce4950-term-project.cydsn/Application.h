/**
 * Application
 * @author Curt Henrichs
 * @date 1-11-18
 *
 * Application layer demo program for term project.
 * TODO: Stubbed module for future
 */

#ifndef APPLICATION_H
#define APPLICATION_H
   
//=============================================================================
//                           Public Function Prototypes
//=============================================================================

/**
 * Application main function will run demo program for term project
 * @return --ignore
 */
int app_main(void);
    
#endif
    