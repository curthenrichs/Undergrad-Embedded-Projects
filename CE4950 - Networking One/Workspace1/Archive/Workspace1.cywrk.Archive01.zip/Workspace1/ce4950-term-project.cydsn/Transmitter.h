/**
 * Transmitter
 * @author Curt Henrichs
 * @date 1-1-2018
 *
 * Transmitter module handles RZ encoded message clockout to network bus. This
 * module has an optional mode to enable/disbale stop on collision behavior. 
 * (Normally enabled). Note that this module requires global interrupts to be
 * enabled. 
 */

#ifndef TRANSMITTER_H
#define TRANSMITTER_H
    
//=============================================================================
//                                 Libraries
//=============================================================================
    
#include <stdbool.h>
#include <stdint.h>
    
//=============================================================================
//                        Constant and Macro Definitions
//=============================================================================

/**
 * Return codes for transmission module transmit functions
 */
typedef enum Tx_Return_States {
    TX_SUCCESS,             //! Transmission successful
    TX_FORMAT_WARNING,      //! Character is not ASCII
    TX_INVALID_PARAMETERS,  //! Function parameters are not as expected
    TX_COLLISION_FAIL,      //! Collision detected during transmission
    TX_TIMEOUT              //! Message timed out waiting for idle condition
} Tx_Return_States_e;

#define TX_MAX_BUFFER_LENGTH (44)   //! Maximum message size allowed on bus
    
//=============================================================================
//                          Public Function Prototypes
//=============================================================================
    
/**
 * Initialize transmitter module for data clockout
 */
void tx_init(void);
/**
 * Transmits a character over bus
 * @param c is character to transmit in ASCII
 * @return return code, success, warning, or collision
 */
Tx_Return_States_e tx_char(char c);
/**
 * Tranmsits a string of character over bus
 * @param buff is buffer start address in memory
 * @param length is number of characters in buffer to transmit
 * @return return code, (from tx_char) and invalid parameter
 */
Tx_Return_States_e tx_buffer(const char* buff, uint8_t length);
/**
 * Transmits a character over bus with precaution on bus state
 * Note that this function does use the channel monitor.
 * @param c is character to transmit in ASCII
 * @param timeout is time to wait before premature exit. (0 to ignore)
 * @return return code, success, warning, collision, or timeout
 */
Tx_Return_States_e tx_sf_char(char c, uint32_t timeout);
/**
 * Tranmsits a string of character over bus with precaution on bus state
 * Note that this function does use the channel monitor.
 * @param buff is buffer start address in memory
 * @param length is number of characters in buffer to transmit
 * @param timeout is time to wait before premature exit. (0 to ignore)
 * @return return code, (from tx_char but not warning) and invalid parameter
 */
Tx_Return_States_e tx_sf_buffer(const char* buff, uint8_t length, uint32_t timeout);
/**
 * Toggles flag to check for collision, and stop transmission on collision
 * @param s is new state for using collision detection
 */
void tx_detect_collision(bool s);
   
#endif
    