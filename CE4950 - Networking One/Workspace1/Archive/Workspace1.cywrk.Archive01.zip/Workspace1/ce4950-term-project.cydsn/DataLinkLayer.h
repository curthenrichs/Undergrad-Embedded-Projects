/**
 * DataLinkLayer
 * @author Curt Henrichs
 * @date 1-26-18
 *
 * Aggregates all of the low level driver components into a cohesive interface 
 * for higher level application services. Additionally, wraps low-level bus
 * read/write into a data frame containing header and routing information.
 *
 * Low-Level drivers include
 *  - CSMA_CD_Bus
 *  - ChannelMonitor
 *  - Transmitter
 *  - Receiver
 */

#ifndef DATALINKLAYER_H
#define DATALINKLAYER_H
    
//=============================================================================
//                                 Libraries
//=============================================================================
    
#include <project.h>
#include <stdbool.h>
    
#include "UserAddressAllocation.h"
#include "CSMA_CD_Bus.h"
#include "ChannelMonitor.h"
#include "Transmitter.h"
#include "Receiver.h"
    
//=============================================================================
//                        Constant and Macro Definitions
//=============================================================================

/**
 * Number of bytes allowed in a transmission packet
 */
#define DL_PACKET_SIZE_TX (TX_MAX_BUFFER_LENGTH)
/**
 * Number of bytes allowed in a receive packet
 */
#define DL_PACKET_SIZE_RX (RX_MAX_BUFFER_LENGTH)
    
typedef enum DLL_CRC_Use {
    DLL_NO_CRC,
    DLL_HEADER_CRC,
    DLL_MESSAGE_CRC,
    DLL_BOTH_CRC
} DLL_CRC_Use_e;
    
//=============================================================================
//                            Data Structure Declaration
//=============================================================================
    
typedef struct DLL_Message {
    uint8_t src;
    uint8_t dst;
    DLL_CRC_Use_e use_crc;
    char* buffer;
    uint8_t buffer_size;
} DLL_Message_t;
    
//=============================================================================
//                               Function Mapping
//=============================================================================

/**
 * Data link layer initialization function will start all bus level sub-drivers
 */
static inline void dl_init(void){
    csma_bus_init();
    cm_init();
    tx_init();
    rx_init();
}
/**
 * Tranmsits a string of character over bus with precaution on bus state
 * Note that this function does use the channel monitor.
 * @param buff is buffer start address in memory
 * @param length is number of characters in buffer to transmit
 * @param timeout is time to wait before premature exit. (0 to ignore)
 * @return return code, TIMEOUT, WARNING, ERROR
 */    
#define dl_tx_buffer(buffer,length,timeout) (tx_sf_buffer(buffer,length,timeout))
/**
 * Receiver checks if a message has been retrieved
 * @return true if a message needs to be read, else false
 */
#define dl_rx_check() (rx_has_data())
/**
 * Receiver message copy function. If there exists data to be read, the copy
 * data into provided buffer
 * @param buffer is valid pointer to character buffer to place data
 * @param length is size of buffer passed in as parameter (must be at least 
 *        protocol MAX)
 * @return number of characters copied into buffer
 */
#define dl_rx_buffer(buffer,length) (rx_buffer(buffer,length))
/**
 * Gets current state from channel monitor, accurate to last bit received
 * @return INIT, IDLE, BUSY, COLLISION
 */
#define dl_ch_state() (cm_get_bus_state)

//=============================================================================
//                          Public Function Prototypes
//=============================================================================
    
void dll_init(void);

void dll_set_user(UserName_e user);

UserName_e dll_get_user(void);

bool dll_update(void);

bool dll_write(DLL_Message_t* message);

bool dll_has_data(void);

uint8_t dll_read(DLL_Message_t* message);

#endif
    