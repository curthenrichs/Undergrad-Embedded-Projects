/**
 * Transmitter
 * @author Curt Henrichs
 * @date 1-1-2018
 *
 * Transmitter module handles RZ encoded message clockout to network bus. This
 * module has an optional mode to enable/disbale stop on collision behavior. 
 * (Normally enabled). Note that this module requires global interrupts to be
 * enabled. 
 */

//=============================================================================
//                                 Libraries
//=============================================================================

#include "Transmitter.h"
#include <project.h>
#include "CSMA_CD_Bus.h"
#include "ChannelMonitor.h"
#include <stdlib.h>

//=============================================================================
//                        Constant and Macro Definitions
//=============================================================================

#define TX_START_MASK (0x80)    //! One is most significant bit of byte

//=============================================================================
//                          Data Structure Declaration
//=============================================================================

/**
 * Character Transmission state-machine
 */
typedef struct Tx_State_Machine {
    uint8_t t_bit;  //! transmission mask (indicates which bit is active)
    bool rz_bit;    //! toggle bit for which half of bit is being sent on line 
    bool end;       //! end flag signals complete tranmission of character
    uint8_t c;      //! character to transmit
} Tx_State_Machine_t;

//=============================================================================
//                             Private Attributes
//=============================================================================

/**
 * Mode to enable or disbale collision detection failure behavior
 */
static bool _detect_collision = false;
/**
 * State-machine to transmit a character on bus
 */
static volatile Tx_State_Machine_t _tx_sm;

//=============================================================================
//                           Private ISR Prototypes
//=============================================================================

/**
 * Transmission timer ISR operates on _tx_sm state_machine to transmit a single
 * character on the network bus. The encoding used is RZ where logic high is a
 * binary one and logic low is a binary zero.
 */
CY_ISR_PROTO(tx_timer_isr);

//=============================================================================
//                        Public Function Implementation
//=============================================================================

/**
 * Initialize transmitter module for data clockout
 */
void tx_init(void){
    Tx_Timer_Start();
    Tx_Timer_Stop();
    Tx_Timer_int_StartEx(tx_timer_isr);
}

/**
 * Transmits a character over bus
 * @param c is character to transmit in ASCII
 * @return return code, success, warning, or collision
 */
Tx_Return_States_e tx_char(char c){
    Tx_Return_States_e retval = TX_SUCCESS;
    
    //format ASCII characater for transmission
    uint8_t tc = (uint8_t)(c);
    if(tc >= TX_START_MASK){
        retval = TX_FORMAT_WARNING;
    }
    tc |= TX_START_MASK;
    
    //start transmit state_machine
    _tx_sm.t_bit = TX_START_MASK;
    _tx_sm.rz_bit = true;
    _tx_sm.c = tc;
    _tx_sm.end = false;
    
    //wait for state machine state to signal end
    Tx_Timer_Start();
    while(!_tx_sm.end && retval != TX_COLLISION_FAIL){
        if(_detect_collision && cm_get_bus_state() == CM_STATE_COLLISION){
            retval = TX_COLLISION_FAIL;   
        }
    }
    _tx_sm.end = true;
    CSMA_TX_Write(0);
    Tx_Timer_Stop();
    
    return retval;
}

/**
 * Tranmsits a string of character over bus
 * @param buff is buffer start address in memory
 * @param length is number of characters in buffer to transmit
 * @return return code, (from tx_char but not warning) and invalid parameter
 */
Tx_Return_States_e tx_buffer(const char* buff, uint8_t length){
    //parameter check
    if(buff == NULL || length  > TX_MAX_BUFFER_LENGTH){
        return TX_INVALID_PARAMETERS;
    }else if(length == 0){
        return TX_SUCCESS; //short circuit logic for no characters
    }
    
    //iterate through buffer transmitting each character
    Tx_Return_States_e retval = TX_SUCCESS;
    Tx_Return_States_e r;
    uint8_t i;
    for(i = 0; i < length && retval != TX_COLLISION_FAIL; ++i){
        r = tx_char(buff[i]);
        if(r == TX_COLLISION_FAIL){
            retval = r;   
        }
    }
    
    return retval;
}

/**
 * Transmits a character over bus with precaution on bus state
 * Note that this function does use the channel monitor.
 * @param c is character to transmit in ASCII
 * @param timeout is time to wait before premature exit. (0 to ignore)
 * @return return code, success, warning, collision, or timeout
 */
Tx_Return_States_e tx_sf_char(char c, uint32_t timeout){
    uint32_t t = 0; 
    Tx_Return_States_e res;
    
    do{
        //wait until idle / timeout
        while(cm_get_bus_state() != CM_STATE_IDLE){
            if(timeout != 0 && t >= timeout){
                return TX_TIMEOUT;   
            }
            CyDelay(1);
            t++;
        }
        
        //collision detect tx character
        bool dc = _detect_collision;
        _detect_collision = true;
        res = tx_char(c);
        _detect_collision = dc;
        
        //backoff time
        if(res == TX_COLLISION_FAIL){
            uint32_t delay = ((float)(rand()) / RAND_MAX) * 1000;
            t += delay;
            if(timeout != 0 && t >= timeout){
                return TX_TIMEOUT;   
            }
            CyDelay(delay);
        }
    } while(res == TX_COLLISION_FAIL); 
    
    return res;
}

/**
 * Tranmsits a string of character over bus with precaution on bus state
 * Note that this function does use the channel monitor.
 * @param buff is buffer start address in memory
 * @param length is number of characters in buffer to transmit
 * @param timeout is time to wait before premature exit. (0 to ignore)
 * @return return code, (from tx_char but not warning) and invalid parameter
 */
Tx_Return_States_e tx_sf_buffer(const char* buff, uint8_t length, uint32_t timeout){
    uint32_t t = 0; 
    Tx_Return_States_e res;
    
    do{
        //wait until idle / timeout
        while(cm_get_bus_state() != CM_STATE_IDLE){
            if(timeout != 0 && t >= timeout){
                return TX_TIMEOUT;   
            }
            CyDelay(1);
            t += 1;
        }
        
        //collision detect tx character
        bool dc = _detect_collision;
        _detect_collision = true;
        res = tx_buffer(buff,length);
        _detect_collision = dc;
        
        //backoff time
        if(res == TX_COLLISION_FAIL){
            uint32_t delay = ((float)(rand()) / RAND_MAX) * 1000;
            t += delay;
            if(timeout != 0 && t >= timeout){
                return TX_TIMEOUT;   
            }
            CyDelay(delay);
        }
    } while(res == TX_COLLISION_FAIL); 
    
    return res;
}

/**
 * Toggles flag to check for collision, and stop transmission on collision
 * @param s is new state for using collision detection
 */
void tx_detect_collision(bool s){
    _detect_collision = s;
}

//=============================================================================
//                           Private ISR Implementation
//=============================================================================

/**
 * Transmission timer ISR operates on _tx_sm state_machine to transmit a single
 * character on the network bus. The encoding used is RZ where logic high is a
 * binary one and logic low is a binary zero.
 */
CY_ISR(tx_timer_isr){
    
    if(!_tx_sm.end){
        
        // Send data bit
        if(_tx_sm.rz_bit){
            CSMA_TX_Write((_tx_sm.c & _tx_sm.t_bit) != 0);
            _tx_sm.t_bit >>= 1;
            _tx_sm.rz_bit = false;
        }
        // Send ground reference
        else{
            CSMA_TX_Write(0);
            _tx_sm.rz_bit = true;
        }
    }
    
    //check for end state
    if(_tx_sm.t_bit == 0 && _tx_sm.rz_bit){
        CSMA_TX_Write(0);
        _tx_sm.end = true;
    }
    
    //clear interrupt
    Tx_Timer_ReadStatusRegister();
}