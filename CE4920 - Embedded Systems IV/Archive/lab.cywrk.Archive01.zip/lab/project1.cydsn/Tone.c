
//=============================================================================
//                                  Libraries
//=============================================================================

#include "Tone.h"
#include <project.h>

//=============================================================================
//                             Private Attributes
//=============================================================================

static const uint8_t* _current_buffer = NULL;
static uint32_t _current_buffer_length = 0;
static uint32_t _current_buffer_index = 0;

//=============================================================================
//                         Private Function Prototypes
//=============================================================================

CY_ISR_PROTO(tone_isr);

//=============================================================================
//                        Public Function Implementation
//=============================================================================

void tone_init(void){
    Tone_C_Start();
    Tone_D_Start();
    Tone_Int_StartEx(tone_isr);
}

void tone_set_tune(const uint8_t* buffer, uint32_t length){
    Tone_Int_Disable();
    
    //copy buffer location for playback
    _current_buffer = buffer;
    _current_buffer_length = length;
    _current_buffer_index = 0;
    
    //set up timer counter
    
    Tone_Int_Enable();
}

//=============================================================================
//                        Private Function Implementation
//=============================================================================

CY_ISR(tone_isr){
    if(_current_buffer != NULL){
        if(_current_buffer_index >= _current_buffer_length){
            _current_buffer = NULL;   
        }else{
            //play for current frequency   
        }
    }
}