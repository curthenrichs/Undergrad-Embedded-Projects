
#ifndef DISPLAY_H
#define DISPLAY_H

//=============================================================================
//                                  Libraries
//=============================================================================
    
#include <project.h>
    
//=============================================================================
//                        Constant and Macro Defintions
//=============================================================================
    
#define LCD_HEIGHT      2   //! Rows of display
#define LCD_WIDTH       16  //! Columns of display
#define MAX_PROFILE_NAME_LENGTH   10 //! Max size for valid display of string
#define MAX_PROFILE_DETAIL_LENGTH 16 //! Max size for valid display of string 
    
#define display_clear() LCD_ClearDisplay() //! Aliase for clearing screen
    
//=============================================================================
//                         Public Function Prototypes
//=============================================================================
    
void display_init(void);
void display_welcome(void);
void display_profile_title(void);
void display_profile_option(const char* name, const char* detail);
    
#endif
