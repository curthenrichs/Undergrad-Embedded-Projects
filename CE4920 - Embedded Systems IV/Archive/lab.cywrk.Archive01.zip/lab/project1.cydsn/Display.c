
//=============================================================================
//                                  Libraries
//=============================================================================

#include "Display.h"
#include <project.h>
#include <stdint.h>
#include <stdio.h>

//=============================================================================
//                         Constant and Macro Defintions
//=============================================================================

#define BLOCK_CHAR  LCD_CUSTOM_0 //! Custom Block Character for top row

//=============================================================================
//                         Private Function Prototypes
//=============================================================================

static void _fill_blocks(void);
static void _welcome_msg(void);

//=============================================================================
//                        Public Function Implementation
//=============================================================================

void display_init(void){
    LCD_Start();
}

void display_welcome(void){
    _fill_blocks();
    _welcome_msg();
}

void display_profile_title(void){
    display_clear();
    LCD_Position(0,0);
    LCD_PrintString("Profile Menu");
    LCD_Position(1,0);
    LCD_PrintString("Next 1, Select 2");
}

void display_profile_option(const char* name, const char* detail){
    if(name == NULL || detail == NULL){
        return; //invalid input   
    }else if(strlen(name) > MAX_PROFILE_NAME_LENGTH){
        return; //invalid length
    }else if(strlen(detail) > MAX_PROFILE_DETAIL_LENGTH){
        return; //invalid length
    }
    
    display_clear();
    LCD_Position(0,0);
    char temp[17];
    sprintf(temp,"Name: %s",name);
    LCD_PrintString(temp);
    LCD_Position(1,0);
    LCD_PrintString(detail);
    
}

//=============================================================================
//                        Private Function Implementation
//=============================================================================

static void _fill_blocks(void){
    display_clear();
    LCD_Position(0,0);
    for(uint8_t c=0; c<16; ++c){
        LCD_PutChar(BLOCK_CHAR);
        CyDelay(100);
    }
}

static void _welcome_msg(void){
    display_clear();
    LCD_Position(0,3);
    LCD_PrintString("Welcome to");
    LCD_Position(1,2);
    LCD_PrintString("My Treadmill");
}