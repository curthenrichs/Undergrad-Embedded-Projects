/*******************************************************************************
* File Name: PIEZO.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PIEZO_H) /* Pins PIEZO_H */
#define CY_PINS_PIEZO_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PIEZO_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 PIEZO__PORT == 15 && ((PIEZO__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    PIEZO_Write(uint8 value);
void    PIEZO_SetDriveMode(uint8 mode);
uint8   PIEZO_ReadDataReg(void);
uint8   PIEZO_Read(void);
void    PIEZO_SetInterruptMode(uint16 position, uint16 mode);
uint8   PIEZO_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the PIEZO_SetDriveMode() function.
     *  @{
     */
        #define PIEZO_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define PIEZO_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define PIEZO_DM_RES_UP          PIN_DM_RES_UP
        #define PIEZO_DM_RES_DWN         PIN_DM_RES_DWN
        #define PIEZO_DM_OD_LO           PIN_DM_OD_LO
        #define PIEZO_DM_OD_HI           PIN_DM_OD_HI
        #define PIEZO_DM_STRONG          PIN_DM_STRONG
        #define PIEZO_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define PIEZO_MASK               PIEZO__MASK
#define PIEZO_SHIFT              PIEZO__SHIFT
#define PIEZO_WIDTH              1u

/* Interrupt constants */
#if defined(PIEZO__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in PIEZO_SetInterruptMode() function.
     *  @{
     */
        #define PIEZO_INTR_NONE      (uint16)(0x0000u)
        #define PIEZO_INTR_RISING    (uint16)(0x0001u)
        #define PIEZO_INTR_FALLING   (uint16)(0x0002u)
        #define PIEZO_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define PIEZO_INTR_MASK      (0x01u) 
#endif /* (PIEZO__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PIEZO_PS                     (* (reg8 *) PIEZO__PS)
/* Data Register */
#define PIEZO_DR                     (* (reg8 *) PIEZO__DR)
/* Port Number */
#define PIEZO_PRT_NUM                (* (reg8 *) PIEZO__PRT) 
/* Connect to Analog Globals */                                                  
#define PIEZO_AG                     (* (reg8 *) PIEZO__AG)                       
/* Analog MUX bux enable */
#define PIEZO_AMUX                   (* (reg8 *) PIEZO__AMUX) 
/* Bidirectional Enable */                                                        
#define PIEZO_BIE                    (* (reg8 *) PIEZO__BIE)
/* Bit-mask for Aliased Register Access */
#define PIEZO_BIT_MASK               (* (reg8 *) PIEZO__BIT_MASK)
/* Bypass Enable */
#define PIEZO_BYP                    (* (reg8 *) PIEZO__BYP)
/* Port wide control signals */                                                   
#define PIEZO_CTL                    (* (reg8 *) PIEZO__CTL)
/* Drive Modes */
#define PIEZO_DM0                    (* (reg8 *) PIEZO__DM0) 
#define PIEZO_DM1                    (* (reg8 *) PIEZO__DM1)
#define PIEZO_DM2                    (* (reg8 *) PIEZO__DM2) 
/* Input Buffer Disable Override */
#define PIEZO_INP_DIS                (* (reg8 *) PIEZO__INP_DIS)
/* LCD Common or Segment Drive */
#define PIEZO_LCD_COM_SEG            (* (reg8 *) PIEZO__LCD_COM_SEG)
/* Enable Segment LCD */
#define PIEZO_LCD_EN                 (* (reg8 *) PIEZO__LCD_EN)
/* Slew Rate Control */
#define PIEZO_SLW                    (* (reg8 *) PIEZO__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PIEZO_PRTDSI__CAPS_SEL       (* (reg8 *) PIEZO__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PIEZO_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PIEZO__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PIEZO_PRTDSI__OE_SEL0        (* (reg8 *) PIEZO__PRTDSI__OE_SEL0) 
#define PIEZO_PRTDSI__OE_SEL1        (* (reg8 *) PIEZO__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PIEZO_PRTDSI__OUT_SEL0       (* (reg8 *) PIEZO__PRTDSI__OUT_SEL0) 
#define PIEZO_PRTDSI__OUT_SEL1       (* (reg8 *) PIEZO__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PIEZO_PRTDSI__SYNC_OUT       (* (reg8 *) PIEZO__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(PIEZO__SIO_CFG)
    #define PIEZO_SIO_HYST_EN        (* (reg8 *) PIEZO__SIO_HYST_EN)
    #define PIEZO_SIO_REG_HIFREQ     (* (reg8 *) PIEZO__SIO_REG_HIFREQ)
    #define PIEZO_SIO_CFG            (* (reg8 *) PIEZO__SIO_CFG)
    #define PIEZO_SIO_DIFF           (* (reg8 *) PIEZO__SIO_DIFF)
#endif /* (PIEZO__SIO_CFG) */

/* Interrupt Registers */
#if defined(PIEZO__INTSTAT)
    #define PIEZO_INTSTAT            (* (reg8 *) PIEZO__INTSTAT)
    #define PIEZO_SNAP               (* (reg8 *) PIEZO__SNAP)
    
	#define PIEZO_0_INTTYPE_REG 		(* (reg8 *) PIEZO__0__INTTYPE)
#endif /* (PIEZO__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_PIEZO_H */


/* [] END OF FILE */
