
#include "project.h"

int main(void){
    CyGlobalIntEnable;
}
